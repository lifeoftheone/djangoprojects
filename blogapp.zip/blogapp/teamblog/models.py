from django.db import models
from datetime import datetime
from taggit.managers import TaggableManager


class User(models.Model):
    """
    Create a register table in database
    """
    name = models.CharField(max_length=50)
    age = models.IntegerField(default=0)
    gender = models.CharField(max_length=6)
    mobile = models.CharField(max_length=16, default='')
    highest_degree = models.CharField(max_length=20)
    email = models.CharField(max_length=64, default='')
    password = models.IntegerField()
    admin = models.BooleanField(default='FALSE')



class Blog(models.Model):
    """
    Create a blog table in database
    """
    title = models.CharField(max_length=30)
    body = models.TextField(max_length=200)
    date = models.DateTimeField(auto_now_add=True)
    email = models.CharField(max_length=64, default='')
    tag = models.CharField(max_length=50)

class Comment(models.Model):
    """
    Create a comment table in database
    """
    name = models.CharField(max_length=15)
    email = models.CharField(max_length=64, default="")
    comment = models.TextField(max_length=50)
    date = models.DateTimeField(auto_now_add=True)
