from django.shortcuts import render, redirect
from .models import *
from .forms import AddupdateblogForm
from django.template.defaultfilters import slugify


def homepage(request):
    """
    Function to retrieve and display all employee records.
    Returns:
        Return a html file with particular name with all the records
    """
    context = {'homepage': Blog.objects.all().order_by('-date')}
    return render(request, "teamblog/homepage.html", context)


def blog(request, id):
    """
    Function to retrieve and display  blog of particular id.
    Returns:
        Return a html file with particular blog and details.
    """
    blogs = Blog.objects.get(pk=id)
    return render(request, 'teamblog/blog.html', {'blogs': blogs},{'emailid': request.session['id']})


def login(request):
    """
    Function to login the user with the emailid and password.
    Returns:
        Return a home page after login.
    """
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        e = User.objects.filter(email=email, password=password).values()
        if e:
            request.session['id'] = email
            print(e[0]['admin'])
            request.session['isadmin'] = e[0]['admin']

            return redirect('/teamblog/bloghomepage')
        else:
            return render(request, 'teamblog/login.html', {'error': 'User name and password invaild'})
        # return render(request, 'teamblog/login.html')
    else:
        return render(request, 'teamblog/login.html')


def blog_homepage(request):
    """
    Function to retrieve and display all employee records.
    Returns:
        Return a html file with particular name with all the records
    """
    context = {'blogs': Blog.objects.all().order_by('-date'), 'emailid': request.session['id'],
               'isadmin': request.session['isadmin']}
    return render(request, 'teamblog/bloghomepage.html', context)


def register(request):
    """
    Function to register the user.
    Returns:
        After registering the user it redirect to home.
    """
    if request.method == 'POST':
        name = request.POST['name']
        age = request.POST['age']
        gender = request.POST['gender']
        mobile = request.POST['mobile']
        highest_degree = request.POST['highest_degree']
        email = request.POST['email']
        password = request.POST['password']
        admin = request.POST['admin']
        user = User.objects.create(name=name, age=age, gender=gender, mobile=mobile, highest_degree=highest_degree,
                                   email=email, password=password, admin=admin)
        user.save()
        return redirect('/teamblog/bloghomepage/')
    else:
        return render(request, 'teamblog/register.html')


def add_update_blog(request, id=0):
    """
    Function to save and update new or old records.
    Args:
        request,id
    Returns:
        Return to home after adding a blog.
    """
    if request.method == "GET":
        if id == 0:
            return render(request, 'teamblog/add_update_blog.html', {'emailid': request.session['id']})
        else:
            blog = Blog.objects.get(pk=id)
            return render(request, "teamblog/add_update_blog.html", {'blog': blog})
    else:
        if id == 0:
            form = AddupdateblogForm(request.POST)
        else:
            blog = Blog.objects.get(pk=id)
            form = AddupdateblogForm(request.POST, instance=blog)
        if form.is_valid():
            form.save()
            return redirect('/teamblog/bloghomepage/')


def blog_delete(request, id):
    """
    Function to delete.
    Args:
        id
    Returns:
        Return to home with details
    """
    blog = Blog.objects.get(pk=id)
    blog.delete()
    return redirect('/teamblog/bloghomepage/')


def comment(request, id):
    """
    Function to post a comment
    Args:
        request,id
    Returns:
        Return to homepage
    """
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        comment = request.POST['comment']
        blog = Blog.objects.filter(id=id)
        comments = Comment.objects.create(id=id, name=name, email=email, comment=comment)
        for blog in blog:
            a = blog.email
        if a == email:
                return render(request, 'teamblog/comment.html', {'error': 'user can not comment on your own post'})
        else:
            comments.save()
            return redirect('/teamblog/')
    else:
        blog = {Blog.objects.filter(id=id)}
        return render(request, 'teamblog/comment.html', {'blog': blog}, {'emailid': request.session['id']})


def readcomment(request, id):
    """
    Function to retrieve and display all  records.
    Returns:
        Return a html file all the records.
    """

    comments = {'comments': Comment.objects.filter(id=id).order_by('-date')}
    return render(request, 'teamblog/readcomment.html', comments)
