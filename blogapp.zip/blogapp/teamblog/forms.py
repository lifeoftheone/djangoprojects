from django import forms
from django.http import request

from .models import *


class AddupdateblogForm(forms.ModelForm):
    """
    create a form for blog model.
    """
    class Meta:
        model = Blog
        fields = ('title', 'body', 'email', 'tag')

    def __init__(self, *args, **kwargs):
        super(AddupdateblogForm, self).__init__(*args, **kwargs)