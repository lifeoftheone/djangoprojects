from django.apps import AppConfig


class TeamblogConfig(AppConfig):
    name = 'teamblog'
